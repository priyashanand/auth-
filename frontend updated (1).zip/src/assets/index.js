import logo from "./xtrans-logo.png";
import graph from "./graph.png";
import wel from "./welcome_xtrans.png";

const Images = {logo, graph, wel};


export default Images;