# This is authentication for Xtrans IoT project

## Requirements to run the server 

1. change your directory to server

        cd server

2. install all dependencies

        npm install 

3. in index.js change the url of you database 

4. 

restriction of cannnel 4 cahnnel 5 fields

authentication email


https://www.youtube.com/watch?v=Qfh2tWa1rBU

mongodb+srv://xtrans:xtranscloud@cluster0.8rn7t.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0
